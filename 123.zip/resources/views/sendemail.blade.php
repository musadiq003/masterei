<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<ul>
	





	<li>
		Name : {{$data['name']}}
		
	</li>

	<li>
		Email : {{$data['email']}}
		
	</li>

	<li>
		Subject : {{$data['subject']}}
		
	</li>

	<li>Message : {{$data['message']}}
		
	</li>
</ul>
</body>
</html>

